﻿using System;

namespace TicTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            bool playagain = true;
            string temp;
            while (playagain)
            {
                Console.Clear();
                SingleRound();
                Console.WriteLine("wanna play again? (yes / no)");
                temp = Console.ReadLine();
                Console.WriteLine("");
                while (temp != "yes" && temp != "no")
                {
                    Console.WriteLine("pls say yes or no!");
                    temp = Console.ReadLine();
                    Console.WriteLine("");
                }
                if (temp == "no")
                {
                    playagain = false;
                }
            }

        }
        public static void SingleRound()
        {
            TicTacToe ttt = new TicTacToe();
            bool IsGameRunning = true;
            int row = 0, col = 0;
            for (int i = 0; i < 9 && IsGameRunning; i++)
            {
                Console.WriteLine(ttt.ToString() + "\n");
                Console.WriteLine("Where do you want to put your sign?");
                Console.WriteLine("Where the first number is the column and the second is the row(between 1-3)");
                try
                {
                    col = int.Parse(Console.ReadLine());
                    row = int.Parse(Console.ReadLine());
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }
                Console.Clear();
                Console.WriteLine("");
                if (i % 2 == 0)
                {
                    while (!ttt.PutSign(row, col, 'X'))
                    {
                        Console.WriteLine(ttt.ToString() + "\n");
                        Console.WriteLine("pls input a correct number");
                        Console.WriteLine("Where the first number is the column and the second is the row(between 1-3)");
                        row = int.Parse(Console.ReadLine());
                        col = int.Parse(Console.ReadLine());
                    }
                    if (ttt.IsWinning('X'))
                    {
                        Console.WriteLine(ttt.ToString() + "\n");
                        Console.WriteLine("X Won!");
                        IsGameRunning = false;
                    }
                }
                else
                {
                    while (!ttt.PutSign(row, col, 'O'))
                    {
                        Console.WriteLine(ttt.ToString() + "\n");
                        Console.WriteLine("pls input a correct number");
                        Console.WriteLine("Where the first number is the column and the second is the row(between 1-3)");
                        row = int.Parse(Console.ReadLine());
                        col = int.Parse(Console.ReadLine());
                    }
                    if (ttt.IsWinning('O'))
                    {
                        Console.WriteLine(ttt.ToString() + "\n");
                        Console.WriteLine("O Won!");
                        IsGameRunning = false;
                    }
                }
            }
            if (IsGameRunning)
            {
                Console.WriteLine("It's a Tie!");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe
{
    class TicTacToe
    {
        char[,] board;
        public TicTacToe()
        {
            board = new char[4, 4];
            for (int i = 1; i < 4; i++)
            {
                for (int j = 1; j < 4; j++)
                {
                    board[i, j] = ' ';
                }
            }
        }
        public bool CanUse(int row, int col)
        {
            if (row >= 1 && row <= 3 && col >= 1 && col <= 3)
            {
                if (board[row, col] == ' ')
                {
                    return true;
                }
            }
            return false;
        }
        public bool PutSign(int row, int col, char ch)
        {
            if (CanUse(row, col) == true)
            {
                board[row, col] = ch;
                return true;
            }
            return false;
        }
        private bool IsRow(int row, char ch)
        {
            if (board[row, 1] == ch && board[row, 2] == ch && board[row, 3] == ch)
            {
                return true;
            }
            return false;
        }
        private bool IsColumn(int col, char ch)
        {
            if (board[1, col] == ch && board[2, col] == ch && board[3, col] == ch)
            {
                return true;
            }
            return false;
        }
        private bool IsFirstDiagonal(char ch)
        {
            if (board[1, 1] == ch && board[2, 2] == ch && board[3, 3] == ch)
            {
                return true;
            }
            return false;
        }
        private bool IsSecondDiagonal(char ch)
        {
            if (board[1, 3] == ch && board[2, 2] == ch && board[3, 1] == ch)
            {
                return true;
            }
            return false;
        }
        public bool IsWinning(char ch)
        {
            for (int i = 1; i < 4; i++)
            {
                if (IsRow(i, ch) || IsColumn(i, ch))
                {
                    return true;
                }

            }
            return IsFirstDiagonal(ch) || IsSecondDiagonal(ch);
        }
        public override string ToString()
        {
            return $" {board[1, 1]}|{board[1, 2]}|{board[1, 3]} \n ----- \n {board[2, 1]}|{board[2, 2]}|{board[2, 3]} \n ----- \n {board[3, 1]}|{board[3, 2]}|{board[3, 3]}";
        }
    }
}
